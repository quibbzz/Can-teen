﻿namespace Can_teen
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.spriteqty = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.spribtn = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lumpqty = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lumpbtn = new System.Windows.Forms.RadioButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.waterqty = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.waterbtn = new System.Windows.Forms.RadioButton();
            this.panel11 = new System.Windows.Forms.Panel();
            this.cokeqty = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.cokebtn = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panqty = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pancitbtn = new System.Windows.Forms.RadioButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pizzqty = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pizzbtn = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.ginataqty = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.ginabtn = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.hambtn = new System.Windows.Forms.RadioButton();
            this.hamqty = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.siombtn = new System.Windows.Forms.RadioButton();
            this.siomqty = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtboxCustomername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.savebtn = new System.Windows.Forms.Button();
            this.resetbtn = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.gridOrders = new System.Windows.Forms.DataGridView();
            this.connectionbtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(97)))), ((int)(((byte)(29)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1382, 100);
            this.panel1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Can_teen.Properties.Resources.LOGO;
            this.pictureBox1.Location = new System.Drawing.Point(12, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(413, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(97)))), ((int)(((byte)(29)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(12, 106);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(799, 861);
            this.panel2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monument Extended", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(64, 562);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(655, 44);
            this.label2.TabIndex = 9;
            this.label2.Text = "DRINKS AND BEVERAGES";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.spriteqty);
            this.panel9.Controls.Add(this.label22);
            this.panel9.Controls.Add(this.label11);
            this.panel9.Controls.Add(this.pictureBox8);
            this.panel9.Controls.Add(this.spribtn);
            this.panel9.Location = new System.Drawing.Point(557, 618);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(204, 230);
            this.panel9.TabIndex = 8;
            // 
            // spriteqty
            // 
            this.spriteqty.Location = new System.Drawing.Point(124, 193);
            this.spriteqty.Name = "spriteqty";
            this.spriteqty.Size = new System.Drawing.Size(53, 27);
            this.spriteqty.TabIndex = 16;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(17, 198);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(106, 18);
            this.label22.TabIndex = 16;
            this.label22.Text = "Quantity:";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(118, 166);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 18);
            this.label11.TabIndex = 10;
            this.label11.Text = "P20/PC";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox8.Location = new System.Drawing.Point(29, 15);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(148, 143);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // spribtn
            // 
            this.spribtn.AutoSize = true;
            this.spribtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.spribtn.Location = new System.Drawing.Point(15, 164);
            this.spribtn.Name = "spribtn";
            this.spribtn.Size = new System.Drawing.Size(94, 22);
            this.spribtn.TabIndex = 9;
            this.spribtn.TabStop = true;
            this.spribtn.Text = "Sprite";
            this.spribtn.UseVisualStyleBackColor = true;
            this.spribtn.CheckedChanged += new System.EventHandler(this.spribtn_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.lumpqty);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Controls.Add(this.lumpbtn);
            this.panel6.Location = new System.Drawing.Point(557, 317);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(204, 230);
            this.panel6.TabIndex = 5;
            // 
            // lumpqty
            // 
            this.lumpqty.Location = new System.Drawing.Point(124, 193);
            this.lumpqty.Name = "lumpqty";
            this.lumpqty.Size = new System.Drawing.Size(53, 27);
            this.lumpqty.TabIndex = 12;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(17, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 18);
            this.label17.TabIndex = 7;
            this.label17.Text = "Quantity:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(118, 172);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 18);
            this.label10.TabIndex = 8;
            this.label10.Text = "P 5/PC";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox5.Location = new System.Drawing.Point(29, 15);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(148, 143);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // lumpbtn
            // 
            this.lumpbtn.AutoSize = true;
            this.lumpbtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lumpbtn.Location = new System.Drawing.Point(17, 168);
            this.lumpbtn.Name = "lumpbtn";
            this.lumpbtn.Size = new System.Drawing.Size(105, 22);
            this.lumpbtn.TabIndex = 7;
            this.lumpbtn.TabStop = true;
            this.lumpbtn.Text = "Lumpia";
            this.lumpbtn.UseVisualStyleBackColor = true;
            this.lumpbtn.CheckedChanged += new System.EventHandler(this.lumpbtn_CheckedChanged);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.waterqty);
            this.panel10.Controls.Add(this.label21);
            this.panel10.Controls.Add(this.label12);
            this.panel10.Controls.Add(this.pictureBox9);
            this.panel10.Controls.Add(this.waterbtn);
            this.panel10.Location = new System.Drawing.Point(295, 618);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(204, 230);
            this.panel10.TabIndex = 7;
            // 
            // waterqty
            // 
            this.waterqty.Location = new System.Drawing.Point(115, 193);
            this.waterqty.Name = "waterqty";
            this.waterqty.Size = new System.Drawing.Size(53, 27);
            this.waterqty.TabIndex = 15;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(12, 198);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(106, 18);
            this.label21.TabIndex = 15;
            this.label21.Text = "Quantity:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(115, 168);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 18);
            this.label12.TabIndex = 12;
            this.label12.Text = "P 15/PC";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox9.Location = new System.Drawing.Point(29, 15);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(148, 143);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // waterbtn
            // 
            this.waterbtn.AutoSize = true;
            this.waterbtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.waterbtn.Location = new System.Drawing.Point(12, 166);
            this.waterbtn.Name = "waterbtn";
            this.waterbtn.Size = new System.Drawing.Size(99, 22);
            this.waterbtn.TabIndex = 11;
            this.waterbtn.TabStop = true;
            this.waterbtn.Text = "Water";
            this.waterbtn.UseVisualStyleBackColor = true;
            this.waterbtn.CheckedChanged += new System.EventHandler(this.waterbtn_CheckedChanged);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.cokeqty);
            this.panel11.Controls.Add(this.label20);
            this.panel11.Controls.Add(this.label13);
            this.panel11.Controls.Add(this.pictureBox10);
            this.panel11.Controls.Add(this.cokebtn);
            this.panel11.Location = new System.Drawing.Point(35, 618);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(204, 230);
            this.panel11.TabIndex = 6;
            // 
            // cokeqty
            // 
            this.cokeqty.Location = new System.Drawing.Point(115, 193);
            this.cokeqty.Name = "cokeqty";
            this.cokeqty.Size = new System.Drawing.Size(53, 27);
            this.cokeqty.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(12, 198);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(106, 18);
            this.label20.TabIndex = 11;
            this.label20.Text = "Quantity:";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(115, 166);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 18);
            this.label13.TabIndex = 14;
            this.label13.Text = "P 20/PC";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox10.Location = new System.Drawing.Point(29, 15);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(148, 143);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            // 
            // cokebtn
            // 
            this.cokebtn.AutoSize = true;
            this.cokebtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cokebtn.Location = new System.Drawing.Point(12, 164);
            this.cokebtn.Name = "cokebtn";
            this.cokebtn.Size = new System.Drawing.Size(84, 22);
            this.cokebtn.TabIndex = 13;
            this.cokebtn.TabStop = true;
            this.cokebtn.Text = "Coke";
            this.cokebtn.UseVisualStyleBackColor = true;
            this.cokebtn.CheckedChanged += new System.EventHandler(this.cokebtn_CheckedChanged);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.panqty);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Controls.Add(this.pancitbtn);
            this.panel5.Location = new System.Drawing.Point(557, 66);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(204, 230);
            this.panel5.TabIndex = 2;
            // 
            // panqty
            // 
            this.panqty.Location = new System.Drawing.Point(124, 193);
            this.panqty.Name = "panqty";
            this.panqty.Size = new System.Drawing.Size(53, 27);
            this.panqty.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(17, 198);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 18);
            this.label16.TabIndex = 5;
            this.label16.Text = "Quantity:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(118, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "P 15/PC";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox4.Location = new System.Drawing.Point(29, 15);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(148, 143);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pancitbtn
            // 
            this.pancitbtn.AutoSize = true;
            this.pancitbtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pancitbtn.Location = new System.Drawing.Point(15, 166);
            this.pancitbtn.Name = "pancitbtn";
            this.pancitbtn.Size = new System.Drawing.Size(96, 22);
            this.pancitbtn.TabIndex = 5;
            this.pancitbtn.TabStop = true;
            this.pancitbtn.Text = "Pancit";
            this.pancitbtn.UseVisualStyleBackColor = true;
            this.pancitbtn.CheckedChanged += new System.EventHandler(this.pancitbtn_CheckedChanged);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.pizzqty);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.pictureBox6);
            this.panel7.Controls.Add(this.pizzbtn);
            this.panel7.Location = new System.Drawing.Point(295, 317);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(204, 230);
            this.panel7.TabIndex = 4;
            // 
            // pizzqty
            // 
            this.pizzqty.Location = new System.Drawing.Point(115, 194);
            this.pizzqty.Name = "pizzqty";
            this.pizzqty.Size = new System.Drawing.Size(53, 27);
            this.pizzqty.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(12, 200);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(106, 18);
            this.label18.TabIndex = 9;
            this.label18.Text = "Quantity:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(115, 168);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 18);
            this.label9.TabIndex = 6;
            this.label9.Text = "P 20/PC";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox6.Location = new System.Drawing.Point(29, 15);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(148, 143);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pizzbtn
            // 
            this.pizzbtn.AutoSize = true;
            this.pizzbtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pizzbtn.Location = new System.Drawing.Point(12, 166);
            this.pizzbtn.Name = "pizzbtn";
            this.pizzbtn.Size = new System.Drawing.Size(100, 22);
            this.pizzbtn.TabIndex = 5;
            this.pizzbtn.TabStop = true;
            this.pizzbtn.Text = "Tocino";
            this.pizzbtn.UseVisualStyleBackColor = true;
            this.pizzbtn.CheckedChanged += new System.EventHandler(this.pizzbtn_CheckedChanged);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.ginataqty);
            this.panel8.Controls.Add(this.label19);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Controls.Add(this.pictureBox7);
            this.panel8.Controls.Add(this.ginabtn);
            this.panel8.Location = new System.Drawing.Point(35, 317);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(204, 230);
            this.panel8.TabIndex = 3;
            // 
            // ginataqty
            // 
            this.ginataqty.Location = new System.Drawing.Point(115, 195);
            this.ginataqty.Name = "ginataqty";
            this.ginataqty.Size = new System.Drawing.Size(53, 27);
            this.ginataqty.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(12, 200);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(106, 18);
            this.label19.TabIndex = 10;
            this.label19.Text = "Quantity:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(115, 172);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 18);
            this.label8.TabIndex = 4;
            this.label8.Text = "P 25/PC";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox7.Location = new System.Drawing.Point(29, 15);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(148, 143);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // ginabtn
            // 
            this.ginabtn.AutoSize = true;
            this.ginabtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ginabtn.Location = new System.Drawing.Point(3, 168);
            this.ginabtn.Name = "ginabtn";
            this.ginabtn.Size = new System.Drawing.Size(124, 22);
            this.ginabtn.TabIndex = 3;
            this.ginabtn.TabStop = true;
            this.ginabtn.Text = "Ginataan";
            this.ginabtn.UseVisualStyleBackColor = true;
            this.ginabtn.CheckedChanged += new System.EventHandler(this.ginabtn_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.hambtn);
            this.panel4.Controls.Add(this.hamqty);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.pictureBox3);
            this.panel4.Location = new System.Drawing.Point(295, 66);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(204, 230);
            this.panel4.TabIndex = 1;
            // 
            // hambtn
            // 
            this.hambtn.AutoSize = true;
            this.hambtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.hambtn.Location = new System.Drawing.Point(13, 166);
            this.hambtn.Name = "hambtn";
            this.hambtn.Size = new System.Drawing.Size(77, 22);
            this.hambtn.TabIndex = 7;
            this.hambtn.TabStop = true;
            this.hambtn.Text = "Ham";
            this.hambtn.UseVisualStyleBackColor = true;
            this.hambtn.CheckedChanged += new System.EventHandler(this.hambtn_CheckedChanged);
            // 
            // hamqty
            // 
            this.hamqty.Location = new System.Drawing.Point(124, 193);
            this.hamqty.Name = "hamqty";
            this.hamqty.Size = new System.Drawing.Size(53, 27);
            this.hamqty.TabIndex = 5;
            this.hamqty.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(19, 198);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 18);
            this.label15.TabIndex = 4;
            this.label15.Text = "Quantity:";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(115, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 18);
            this.label6.TabIndex = 4;
            this.label6.Text = "P 10/PC";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox3.Location = new System.Drawing.Point(29, 15);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(148, 143);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monument Extended", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(255, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 44);
            this.label1.TabIndex = 1;
            this.label1.Text = "MAIN DISH";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.siombtn);
            this.panel3.Controls.Add(this.siomqty);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Location = new System.Drawing.Point(35, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(204, 230);
            this.panel3.TabIndex = 0;
            // 
            // siombtn
            // 
            this.siombtn.AutoSize = true;
            this.siombtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.siombtn.Location = new System.Drawing.Point(13, 166);
            this.siombtn.Name = "siombtn";
            this.siombtn.Size = new System.Drawing.Size(97, 22);
            this.siombtn.TabIndex = 7;
            this.siombtn.TabStop = true;
            this.siombtn.Text = "Siomai";
            this.siombtn.UseVisualStyleBackColor = true;
            this.siombtn.CheckedChanged += new System.EventHandler(this.siombtn_CheckedChanged);
            // 
            // siomqty
            // 
            this.siomqty.Location = new System.Drawing.Point(115, 193);
            this.siomqty.Name = "siomqty";
            this.siomqty.Size = new System.Drawing.Size(53, 27);
            this.siomqty.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(12, 198);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(106, 18);
            this.label14.TabIndex = 3;
            this.label14.Text = "Quantity:";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(115, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 18);
            this.label5.TabIndex = 2;
            this.label5.Text = "P 8/PC";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Can_teen.Properties.Resources.food;
            this.pictureBox2.Location = new System.Drawing.Point(29, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(148, 143);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(828, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(212, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Customer\'s Name: ";
            // 
            // txtboxCustomername
            // 
            this.txtboxCustomername.Location = new System.Drawing.Point(1033, 115);
            this.txtboxCustomername.Name = "txtboxCustomername";
            this.txtboxCustomername.Size = new System.Drawing.Size(294, 27);
            this.txtboxCustomername.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(818, 785);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "TOTAL:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(905, 776);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(422, 27);
            this.textBox1.TabIndex = 10;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // savebtn
            // 
            this.savebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.savebtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.savebtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.savebtn.Location = new System.Drawing.Point(828, 818);
            this.savebtn.Name = "savebtn";
            this.savebtn.Size = new System.Drawing.Size(499, 50);
            this.savebtn.TabIndex = 11;
            this.savebtn.Text = "SAVE";
            this.savebtn.UseVisualStyleBackColor = false;
            this.savebtn.Click += new System.EventHandler(this.savebtn_Click);
            // 
            // resetbtn
            // 
            this.resetbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(14)))));
            this.resetbtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.resetbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.resetbtn.Location = new System.Drawing.Point(828, 874);
            this.resetbtn.Name = "resetbtn";
            this.resetbtn.Size = new System.Drawing.Size(499, 42);
            this.resetbtn.TabIndex = 12;
            this.resetbtn.Text = "RESET";
            this.resetbtn.UseVisualStyleBackColor = false;
            this.resetbtn.Click += new System.EventHandler(this.resetbtn_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.White;
            this.exitbtn.Font = new System.Drawing.Font("Monument Extended", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.exitbtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.exitbtn.Location = new System.Drawing.Point(828, 922);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(499, 38);
            this.exitbtn.TabIndex = 13;
            this.exitbtn.Text = "EXIT";
            this.exitbtn.UseVisualStyleBackColor = false;
            this.exitbtn.Click += new System.EventHandler(this.exitbtn_Click);
            // 
            // gridOrders
            // 
            this.gridOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridOrders.Location = new System.Drawing.Point(828, 148);
            this.gridOrders.Name = "gridOrders";
            this.gridOrders.RowHeadersWidth = 51;
            this.gridOrders.RowTemplate.Height = 29;
            this.gridOrders.Size = new System.Drawing.Size(499, 564);
            this.gridOrders.TabIndex = 16;
            this.gridOrders.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridOrders_CellContentClick);
            // 
            // connectionbtn
            // 
            this.connectionbtn.Location = new System.Drawing.Point(870, 743);
            this.connectionbtn.Name = "connectionbtn";
            this.connectionbtn.Size = new System.Drawing.Size(94, 29);
            this.connectionbtn.TabIndex = 17;
            this.connectionbtn.Text = "button1";
            this.connectionbtn.UseVisualStyleBackColor = true;
            this.connectionbtn.Click += new System.EventHandler(this.connectionbtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1382, 979);
            this.Controls.Add(this.connectionbtn);
            this.Controls.Add(this.gridOrders);
            this.Controls.Add(this.exitbtn);
            this.Controls.Add(this.resetbtn);
            this.Controls.Add(this.savebtn);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtboxCustomername);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label1;
        private Panel panel3;
        private PictureBox pictureBox2;
        private Label label2;
        private Panel panel9;
        private PictureBox pictureBox8;
        private Panel panel6;
        private PictureBox pictureBox5;
        private Panel panel10;
        private PictureBox pictureBox9;
        private Panel panel11;
        private PictureBox pictureBox10;
        private Panel panel5;
        private PictureBox pictureBox4;
        private Panel panel7;
        private PictureBox pictureBox6;
        private Panel panel8;
        private PictureBox pictureBox7;
        private Panel panel4;
        private PictureBox pictureBox3;
        private Label label3;
        private TextBox txtboxCustomername;
        private Label label4;
        private TextBox textBox1;
        private Button savebtn;
        private Button resetbtn;
        private Button exitbtn;
        private Label label11;
        private RadioButton spribtn;
        private Label label10;
        private RadioButton lumpbtn;
        private Label label12;
        private RadioButton waterbtn;
        private Label label13;
        private RadioButton cokebtn;
        private Label label7;
        private RadioButton pancitbtn;
        private Label label9;
        private RadioButton pizzbtn;
        private Label label8;
        private RadioButton ginabtn;
        private Label label15;
        private Label label6;
        private Label label14;
        private Label label5;
        private Label label22;
        private Label label17;
        private Label label21;
        private Label label20;
        private Label label16;
        private Label label18;
        private Label label19;
        private TextBox panqty;
        private TextBox pizzqty;
        private TextBox ginataqty;
        private TextBox hamqty;
        private TextBox siomqty;
        private TextBox lumpqty;
        private TextBox spriteqty;
        private TextBox waterqty;
        private TextBox cokeqty;
        private RadioButton hambtn;
        private RadioButton siombtn;
        private DataGridView gridOrders;
        private Button connectionbtn;
    }
}